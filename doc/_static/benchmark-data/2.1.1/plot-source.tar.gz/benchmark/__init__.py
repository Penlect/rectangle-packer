"""Benchmark utilities for rpack."""
